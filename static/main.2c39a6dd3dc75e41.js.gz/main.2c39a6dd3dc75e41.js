(()=>{"use strict";var e,r,t,n,a={734:function(e,r,t){t.d(r,{Ay:()=>D,DD:()=>l,Ey:()=>c,Fw:()=>w,GI:()=>h,Hp:()=>g,I2:()=>N,JU:()=>v,P1:()=>p,Sp:()=>u,VY:()=>d,Ye:()=>b,Yk:()=>m,gJ:()=>y,kL:()=>i,me:()=>x,nq:()=>f,pq:()=>j,x6:()=>k});var n=t(601),a=t.n(n),s=t(314),o=t.n(s)()(a());o.push([e.id,`body {
  margin: 0px;
  font-family: 'Lato', sans-serif;
  background-color: #0f172a;
}

.b7Z74QENEW9pEdqh {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-family: system-ui, -apple-system, sans-serif;
  padding: 20px;
}

.YmIxCBETt74Vy4UJ {
  font-size: 2.5rem;
  font-weight: bold;
  margin-bottom: 2rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-align: center;
}

.aDGhAllYTEIVo7Oz {
  background-color: #1e293b;
  border-radius: 20px;
  padding: 3rem;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  border: 1px solid #334155;
  margin-bottom: 2rem;
}

.D5kyGsuPOOsFyQCb {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2vw;
}

.Ep2dRn0_NIMvUy71 {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.h_l_p2uLWN8M45DA {
  font-size: 10vw;
  font-weight: bold;
  color: #60a5fa;
  line-height: 1;
}

.qWtUHxTweATXYwEP {
  font-size: 4vw;
  color: #94a3b8;
  margin-top: 0.5rem;
  text-transform: uppercase;
  letter-spacing: 0.1em;
}

.eUN7qDZLjwaSTkfn {
  font-size: 3rem;
  color: #64748b;
  font-weight: bold;
}

.a21PGyEPHOwZR7a3 {
  background-color: #dc2626;
  border-radius: 20px;
  padding: 3rem;
  text-align: center;
  box-shadow: 0 25px 50px -12px rgba(220, 38, 38, 0.25);
}

.tXjM3eWi_HYX1dgs {
  font-size: 2rem;
  margin-bottom: 1rem;
}

.wU8_3nkxY_6yRsRe {
  font-size: 1.2rem;
  opacity: 0.9;
}

.YJ8uXDHHxUYuqiHR {
  background-color: #dc2626;
  border-radius: 20px;
  padding: 2rem;
  text-align: center;
  max-width: 500px;
  box-shadow: 0 25px 50px -12px rgba(220, 38, 38, 0.25);
}

.VVLeoG4z898vlO4L {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

.cTL_tviIEnYRMcrm {
  font-size: 1rem;
  margin-bottom: 1rem;
  opacity: 0.9;
}

.sMUDvDydrJEORs1d {
  font-size: 0.9rem;
  opacity: 0.8;
}

.AiGm2fMHDW4PuANs {
  color: #94a3b8;
  font-size: 0.9rem;
  text-align: center;
}

.IPCbsV48k0cy6FfD {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.IPCbsV48k0cy6FfD > input[type="submit"]{
  cursor: pointer;
  background-color: #764ba2;
  border-radius: 4px;
  color: white;
  border: 0px solid;
  height: 30px;
}

.fv_C678_px0LUFeZ{
  text-align: center;
}

.fv_C678_px0LUFeZ > button {
  cursor: pointer;
  background-color: #764ba2;
  border-radius: 4px;
  color: white;
  border: 0px solid;
  height: 30px;
  margin: 0 auto;
}`,""]);var i="b7Z74QENEW9pEdqh",l="YmIxCBETt74Vy4UJ",d="aDGhAllYTEIVo7Oz",c="D5kyGsuPOOsFyQCb",m="Ep2dRn0_NIMvUy71",p="h_l_p2uLWN8M45DA",u="qWtUHxTweATXYwEP",x="eUN7qDZLjwaSTkfn",f="a21PGyEPHOwZR7a3",h="tXjM3eWi_HYX1dgs",g="wU8_3nkxY_6yRsRe",b="YJ8uXDHHxUYuqiHR",v="VVLeoG4z898vlO4L",y="cTL_tviIEnYRMcrm",w="sMUDvDydrJEORs1d",j="AiGm2fMHDW4PuANs",N="IPCbsV48k0cy6FfD",k="fv_C678_px0LUFeZ";let D=o},396:function(e,r,t){var n={};t.r(n),t.d(n,{button:()=>b.x6,container:()=>b.kL,countdownBox:()=>b.VY,default:()=>y,errorBox:()=>b.Ye,errorMessage:()=>b.gJ,errorTitle:()=>b.JU,example:()=>b.Fw,expiredBox:()=>b.nq,expiredMessage:()=>b.Hp,expiredTitle:()=>b.GI,formCountdowndate:()=>b.I2,info:()=>b.pq,separator:()=>b.me,timeDisplay:()=>b.Ey,timeLabel:()=>b.Sp,timeUnit:()=>b.Yk,timeValue:()=>b.P1,title:()=>b.DD});var a=t(848),s=t(338),o=t(72),i=t.n(o),l=t(825),d=t.n(l),c=t(659),m=t.n(c),p=t(56),u=t.n(p),x=t(159),f=t.n(x),h=t(113),g=t.n(h),b=t(734),v={};v.styleTagTransform=g(),v.setAttributes=u(),v.insert=m().bind(null,"head"),v.domAPI=d(),v.insertStyleElement=f(),i()(b.Ay,v);let y=b.Ay&&b.Ay.locals?b.Ay.locals:void 0,w=({error:e})=>(0,a.jsx)("div",{className:b.kL,children:(0,a.jsxs)("div",{className:b.Ye,children:[(0,a.jsx)("h2",{className:b.JU,children:"Error"}),(0,a.jsx)("p",{className:b.gJ,children:e}),(0,a.jsxs)("form",{className:b.I2,onSubmit:e=>{e.preventDefault();let r=e.target.countdowndate.value;if(r){let e=new Date(r).toISOString();window.location.search=`?date=${e}`}},children:[(0,a.jsx)("label",{htmlFor:"countdowndate",children:"Countdown date (date and time):"}),(0,a.jsx)("input",{type:"datetime-local",id:"countdowndate",name:"countdowndate"}),(0,a.jsx)("input",{type:"submit"})]})]})});var j=t(540);let N=({targetDateTime:e})=>{let[r,t]=(0,j.useState)(new Date),n=(0,j.useMemo)(()=>{let t=e?.getTime()-r.getTime();if(t<=0)return null;let n=Math.floor(t/1e3),a=Math.trunc(t/864e5),s=Math.trunc((t-864e5*a)/36e5)%60;return{days:a,hours:s,minutes:Math.trunc(t/6e4)%60,seconds:n%60}},[e,r]);return((0,j.useEffect)(()=>{if(!n)return;let e=setInterval(()=>{t(new Date)},1e3);return()=>clearInterval(e)},[]),n)?(0,a.jsx)("div",{className:b.VY,children:(0,a.jsxs)("div",{className:b.Ey,children:[!!n.days&&(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("div",{className:b.Yk,children:[(0,a.jsx)("span",{className:b.P1,children:n.days}),(0,a.jsx)("span",{className:b.Sp,children:"days"})]}),(0,a.jsx)("div",{className:b.me,children:":"})]}),!!n.hours&&(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("div",{className:b.Yk,children:[(0,a.jsx)("span",{className:b.P1,children:n.hours}),(0,a.jsx)("span",{className:b.Sp,children:"hours"})]}),(0,a.jsx)("div",{className:b.me,children:":"})]}),(0,a.jsxs)("div",{className:b.Yk,children:[(0,a.jsx)("span",{className:b.P1,children:n.minutes}),(0,a.jsx)("span",{className:b.Sp,children:"minutes"})]}),(0,a.jsx)("div",{className:b.me,children:":"}),(0,a.jsxs)("div",{className:b.Yk,children:[(0,a.jsx)("span",{className:b.P1,children:n.seconds.toString().padStart(2,"0")}),(0,a.jsx)("span",{className:b.Sp,children:"seconds"})]})]})}):(0,a.jsxs)("div",{className:b.nq,children:[(0,a.jsx)("h2",{className:b.GI,children:"Time's Up! ⏰"}),(0,a.jsx)("p",{className:b.Hp,children:"The countdown has reached zero."})]})},k=document.getElementById("root");(0,s.createRoot)(k).render((0,a.jsx)(()=>{let e,r,{error:t,targetDateTime:s,onCleanDate:o}=(r=new Date(e=new URLSearchParams(window.location.search).get("date")),{error:(0,j.useMemo)(()=>e?isNaN(r.getTime())?"Invalid date format. Please use YYYY-MM-DD format.":void 0:"No date parameter found in URL. Add ?date=YYYY-MM-DD to the URL.",[r,e]),onCleanDate:()=>{window.location.search=""},targetDateTime:r});return t?(0,a.jsx)(w,{error:t}):(0,a.jsxs)("div",{className:n?.content,children:[(0,a.jsx)("h1",{className:b.DD,children:"Countdown Timer"}),(0,a.jsx)(N,{targetDateTime:s}),(0,a.jsx)("div",{className:b.x6,children:(0,a.jsx)("button",{onClick:o,children:"Reset"})})]})},{})),"serviceWorker"in navigator&&navigator.serviceWorker.register("service-worker.js")}},s={};function o(e){var r=s[e];if(void 0!==r)return r.exports;var t=s[e]={id:e,exports:{}};return a[e](t,t.exports,o),t.exports}o.m=a,o.n=e=>{var r=e&&e.__esModule?()=>e.default:()=>e;return o.d(r,{a:r}),r},o.d=(e,r)=>{for(var t in r)o.o(r,t)&&!o.o(e,t)&&Object.defineProperty(e,t,{enumerable:!0,get:r[t]})},o.o=(e,r)=>Object.prototype.hasOwnProperty.call(e,r),o.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},o.nc=void 0,e=[],o.O=(r,t,n,a)=>{if(t){a=a||0;for(var s=e.length;s>0&&e[s-1][2]>a;s--)e[s]=e[s-1];e[s]=[t,n,a];return}for(var i=1/0,s=0;s<e.length;s++){for(var[t,n,a]=e[s],l=!0,d=0;d<t.length;d++)(!1&a||i>=a)&&Object.keys(o.O).every(e=>o.O[e](t[d]))?t.splice(d--,1):(l=!1,a<i&&(i=a));if(l){e.splice(s--,1);var c=n();void 0!==c&&(r=c)}}return r},o.rv=()=>"1.5.8",r={889:0},o.O.j=e=>0===r[e],t=(e,t)=>{var n,a,[s,i,l]=t,d=0;if(s.some(e=>0!==r[e])){for(n in i)o.o(i,n)&&(o.m[n]=i[n]);if(l)var c=l(o)}for(e&&e(t);d<s.length;d++)a=s[d],o.o(r,a)&&r[a]&&r[a][0](),r[a]=0;return o.O(c)},(n=self.webpackChunkcountdown=self.webpackChunkcountdown||[]).forEach(t.bind(null,0)),n.push=t.bind(null,n.push.bind(n)),o.ruid="bundler=rspack@1.5.8";var i=o.O(void 0,["4"],function(){return o(396)});i=o.O(i)})();